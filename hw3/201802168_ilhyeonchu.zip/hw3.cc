#include <iostream>
#include "int_accumulator.h"
#include "float_accumulator.h"

int main() {
printf("아무거나");
return 0;
}
