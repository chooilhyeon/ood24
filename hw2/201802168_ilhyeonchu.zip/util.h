#ifndef _UTIL_H_
#define _UTIL_H_

#include <iostream>
#include <assert.h>

class Util {
 public:
  int Add(int x, int y);
  int Sub(int x, int y);
  int Mul(int x, int y);
  int Div(int x, int y);
};

#endif  // _UTIL_H_
