#include <iostream>
#include "util.h"

int main() {
printf("아무거나");
return 0;
}
