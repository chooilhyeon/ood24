#include <iostream>
#include "int_set.h"

int main() {
printf("아무거나");
return 0;
}
